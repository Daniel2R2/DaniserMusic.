// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/login2/login2_widget.dart' show Login2Widget;
export '/pages/perfil/perfil_widget.dart' show PerfilWidget;
export '/pages/inicio/inicio_widget.dart' show InicioWidget;
