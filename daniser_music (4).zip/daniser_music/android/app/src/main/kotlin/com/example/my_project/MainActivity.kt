package com.mycompany.danisermusic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
